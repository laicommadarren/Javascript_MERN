import React, { useEffect, useState } from 'react';
import ProductForm from '../components/ProductForm';
import Main from './views/Main';

export default () => {
    return (
        <div>
            <ProductForm />
            <Routes>
            <Route path="/" element={<Main/>} />
            </Routes>
        </div>
    )
}