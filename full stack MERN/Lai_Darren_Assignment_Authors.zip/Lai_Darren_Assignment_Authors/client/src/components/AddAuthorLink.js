import React from 'react';
import { Link } from 'react-router-dom';
    
export default () => {
    return (
        <Link to={"/authors/new"}>
            Add an author
        </Link>
    )
}