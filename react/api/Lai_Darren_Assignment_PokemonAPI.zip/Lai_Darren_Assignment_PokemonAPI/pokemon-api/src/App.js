import React, { useState } from 'react';
import ButtonForAPI from './ButtonForAPI';

function App() {

	return (
		<>
		<ButtonForAPI/>
		</>
	);
}

export default App;
