import react, { useState } from 'react';

const BoxDisplay = (props) => { 
    return (
        <>
        {props.showBox.map((item) => {return item})}
        </>
    );
};

export default BoxDisplay;