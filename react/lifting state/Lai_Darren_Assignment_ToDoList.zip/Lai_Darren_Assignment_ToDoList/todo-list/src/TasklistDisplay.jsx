import react, { useState } from 'react';

const TasklistDisplay = (props) => {
    const updateDone = (e, modIndex) => {
        if (e.target.checked) {
            props.setIsDone(true);
            /* const currentList = props.showList.filter((e, index) => index == modIndex 
            ? {...e, isChecked:true} : e ) */
            const currentList = props.showList.map((e, index) => index == modIndex
            ? {...e, isChecked:true} : e)
            props.setShowList(currentList);} 
            
        else {
            props.setIsDone(false);
            // const currentList = props.showList.filter((e, index) => index == modIndex 
            // ? { ...e, isChecked:false} : e )
            const currentList = props.showList.map((e, index) => index == modIndex
            ? { ...e, isChecked:false} : e)
            props.setShowList(currentList);}
        }

    return (
        <>
            {props.showList.map((item, index) => {
                if (item.isChecked) { // if item.isChecked is true, strikethrough
                return (
                    <div key={index}>
                        <div style={{ display: 'flex' }}>
                            <strike>{item.message}</strike>
                            <label>
                                <input
                                    type="checkbox"
                                    checked={props.isDone}
                                    onChange={(e) => updateDone(e, index)}
                                // not sure if I need the arguments passing through
                                />
                            </label>
                            <button onClick={() => props.removeTaskByIndex(index)}>Delete</button>
                        </div>
                    </div>

                );}
                else {
                return (
                    <div key={index}>
                        <div style={{ display: 'flex' }}>
                            {item.message}
                            <label>
                                <input
                                    type="checkbox"
                                    checked={props.isDone}
                                    // but where is isDone coming from since now I have to access it somehow
                                    onChange={(e) => updateDone(e, index)}
                                // not sure if I need the arguments passing through
                                />
                            </label>
                            <button onClick={() => props.removeTaskByIndex(index)}>Delete</button>
                            {/* this removeTaskByIndex will be moved to App.js */}
                        </div>
                    </div>

                )}

            })}
        </>
    )
};

export default TasklistDisplay;