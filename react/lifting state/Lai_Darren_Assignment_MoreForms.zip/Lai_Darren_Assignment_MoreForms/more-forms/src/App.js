import UserForm from "./UserForm";
import React from 'react'

function App() {
  return (
    <div>
      <UserForm/>
    </div>
  );
}

export default App;